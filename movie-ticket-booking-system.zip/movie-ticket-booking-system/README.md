# Movie Ticket Booking System (DBMS Mini Project)

A relational database project built with **MySQL** that manages movies, theatres, shows, customers, bookings and payments.

**Submitted by:** Sanjana Sovanshi (UID 25BCD10108)
**Submitted to:** Mrs. Harkamal Kaur, Assistant Professor
**University:** Chandigarh University

## Database design

Six tables: `movies`, `theatres`, `shows`, `customers`, `bookings`, `payments`.

![ER diagram](screenshots/er.png)

| Relationship | Cardinality |
|---|---|
| movies - shows | 1 : N |
| theatres - shows | 1 : N |
| shows - bookings | 1 : N |
| customers - bookings | 1 : N |
| bookings - payments | 1 : 1 |

## Files (run in this order)

| File | Purpose |
|---|---|
| `01_schema_master.sql` | Creates the database and the movies, theatres, customers tables |
| `02_schema_transaction.sql` | Creates shows, bookings, payments tables (foreign keys, CHECK constraints) |
| `03_insert_master.sql` | Sample data for movies, theatres, customers |
| `04_insert_transaction.sql` | Sample data for shows, bookings, payments |
| `05_queries.sql` | JOIN, GROUP BY, HAVING and aggregate queries |
| `06_view_and_transactions.sql` | View `booking_summary`, cancellation transaction, DELETE example |

## How to run

```sql
mysql -u root -p
source 01_schema_master.sql;
source 02_schema_transaction.sql;
source 03_insert_master.sql;
source 04_insert_transaction.sql;
source 05_queries.sql;
source 06_view_and_transactions.sql;
```

Requires MySQL 8.0.16 or later (CHECK constraints are enforced from this version).

## Concepts covered

DDL, DML, DQL, TCL - primary keys, foreign keys, UNIQUE / CHECK / DEFAULT constraints, joins, aggregate functions, GROUP BY / HAVING, views, transactions (START TRANSACTION / COMMIT).

## Screenshots

See the `screenshots/` folder for the output of every script.
