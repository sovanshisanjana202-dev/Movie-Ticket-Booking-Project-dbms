-- 06_view_and_transactions.sql
USE movie_booking_db;

-- View: one-line summary of every booking
CREATE VIEW booking_summary AS
SELECT b.booking_id, c.name AS customer, m.title AS movie,
       t.name AS theatre, s.show_date, s.show_time, b.seats, b.status
FROM bookings b
JOIN customers c ON b.customer_id = c.customer_id
JOIN shows s     ON b.show_id = s.show_id
JOIN movies m    ON s.movie_id = m.movie_id
JOIN theatres t  ON s.theatre_id = t.theatre_id;

SELECT * FROM booking_summary WHERE show_date = '2026-10-23';

-- Transaction: cancel booking 5006 and release its seats
START TRANSACTION;
UPDATE bookings SET status = 'Cancelled' WHERE booking_id = 5006;
UPDATE payments SET pay_status = 'Refunded' WHERE booking_id = 5006;
UPDATE shows    SET available = available + 5 WHERE show_id = 1005;
COMMIT;

SELECT show_id, capacity, available FROM shows WHERE show_id = 1005;

-- Delete an unpaid (pending) booking and release its seats
DELETE FROM payments WHERE booking_id = 5008;
DELETE FROM bookings WHERE booking_id = 5008;
UPDATE shows SET available = available + 3 WHERE show_id = 1008;
