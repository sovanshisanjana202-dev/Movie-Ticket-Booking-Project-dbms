-- 03_insert_master.sql : movies, theatres, customers
INSERT INTO movies VALUES
(1, 'Dangal', 'Sports Drama', 'Hindi', 161, 8.3, '2016-12-23'),
(2, '3 Idiots', 'Comedy Drama', 'Hindi', 170, 8.4, '2009-12-25'),
(3, 'Jawan', 'Action', 'Hindi', 169, 7.0, '2023-09-07'),
(4, 'Oppenheimer', 'Biography', 'English', 180, 8.3, '2023-07-21'),
(5, 'Animal', 'Crime Drama', 'Hindi', 201, 6.3, '2023-12-01'),
(6, 'Carry On Jatta 3', 'Comedy', 'Punjabi', 147, 6.6, '2023-06-29');

INSERT INTO theatres VALUES
(1, 'CineMax Plaza', 'Chandigarh', 5),
(2, 'Star Multiplex', 'Mohali', 4),
(3, 'Silver Screen', 'Ludhiana', 3),
(4, 'Galaxy Cinemas', 'Panchkula', 4);

INSERT INTO customers VALUES
(101, 'Aarav Sharma', 'aarav.sharma@example.com', '9876500001'),
(102, 'Simran Kaur', 'simran.kaur@example.com', '9876500002'),
(103, 'Rohan Verma', 'rohan.verma@example.com', '9876500003'),
(104, 'Priya Singh', 'priya.singh@example.com', '9876500004'),
(105, 'Karan Mehta', 'karan.mehta@example.com', '9876500005'),
(106, 'Harpreet Gill', 'harpreet.gill@example.com', '9876500006');
