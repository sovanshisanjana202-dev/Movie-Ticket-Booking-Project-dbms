-- 05_queries.sql : data retrieval queries
USE movie_booking_db;

-- Q1: show schedule with movie and theatre
SELECT s.show_id, m.title, t.name AS theatre, s.show_date, s.show_time, s.price
FROM shows s
JOIN movies m   ON s.movie_id = m.movie_id
JOIN theatres t ON s.theatre_id = t.theatre_id
ORDER BY s.show_date, s.show_time;

-- Q2: booking details with customer and movie
SELECT b.booking_id, c.name AS customer, m.title AS movie, s.show_date,
       b.seats, b.amount, b.status
FROM bookings b
JOIN customers c ON b.customer_id = c.customer_id
JOIN shows s     ON b.show_id = s.show_id
JOIN movies m    ON s.movie_id = m.movie_id
ORDER BY b.booking_id;

-- Q3: revenue per movie (confirmed bookings)
SELECT m.title, COUNT(b.booking_id) AS total_bookings,
       SUM(b.seats) AS tickets_sold, SUM(b.amount) AS revenue
FROM movies m
JOIN shows s    ON m.movie_id = s.movie_id
JOIN bookings b ON s.show_id = b.show_id
WHERE b.status = 'Confirmed'
GROUP BY m.title
ORDER BY revenue DESC;

-- Q4: customers with more than one booking
SELECT c.name, COUNT(*) AS total_bookings, SUM(b.amount) AS total_spent
FROM customers c
JOIN bookings b ON c.customer_id = b.customer_id
GROUP BY c.customer_id, c.name
HAVING COUNT(*) > 1;

-- Q5: collection by payment mode
SELECT pay_mode, COUNT(*) AS payments, SUM(amount) AS collected
FROM payments
WHERE pay_status = 'Success'
GROUP BY pay_mode
ORDER BY collected DESC;
