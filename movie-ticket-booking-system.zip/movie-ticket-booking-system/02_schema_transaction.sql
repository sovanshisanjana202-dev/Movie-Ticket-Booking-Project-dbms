-- 02_schema_transaction.sql : transaction tables
CREATE TABLE shows (
    show_id     INT PRIMARY KEY,
    movie_id    INT NOT NULL,
    theatre_id  INT NOT NULL,
    screen      INT NOT NULL,
    show_date   DATE NOT NULL,
    show_time   TIME NOT NULL,
    price       DECIMAL(8,2) NOT NULL,
    capacity    INT NOT NULL,
    available   INT NOT NULL,
    FOREIGN KEY (movie_id)   REFERENCES movies(movie_id),
    FOREIGN KEY (theatre_id) REFERENCES theatres(theatre_id)
);

CREATE TABLE bookings (
    booking_id   INT PRIMARY KEY,
    customer_id  INT NOT NULL,
    show_id      INT NOT NULL,
    book_date    DATE NOT NULL,
    seats        INT NOT NULL CHECK (seats > 0),
    seat_nos     VARCHAR(40) NOT NULL,
    amount       DECIMAL(8,2) NOT NULL,
    status       VARCHAR(10) NOT NULL DEFAULT 'Pending'
                 CHECK (status IN ('Confirmed','Pending','Cancelled')),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (show_id)     REFERENCES shows(show_id)
);

CREATE TABLE payments (
    payment_id  INT PRIMARY KEY,
    booking_id  INT NOT NULL,
    pay_mode    VARCHAR(20) NOT NULL,
    amount      DECIMAL(8,2) NOT NULL,
    pay_status  VARCHAR(10) NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);
