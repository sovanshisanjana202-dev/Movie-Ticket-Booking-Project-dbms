-- 01_schema_master.sql : database + master tables
CREATE DATABASE movie_booking_db;
USE movie_booking_db;

CREATE TABLE movies (
    movie_id      INT PRIMARY KEY,
    title         VARCHAR(100) NOT NULL,
    genre         VARCHAR(30)  NOT NULL,
    language      VARCHAR(20)  NOT NULL,
    duration_min  INT          NOT NULL,
    rating        DECIMAL(2,1),
    release_date  DATE
);

CREATE TABLE theatres (
    theatre_id     INT PRIMARY KEY,
    name           VARCHAR(60) NOT NULL,
    city           VARCHAR(30) NOT NULL,
    total_screens  INT NOT NULL
);

CREATE TABLE customers (
    customer_id  INT PRIMARY KEY,
    name         VARCHAR(60) NOT NULL,
    email        VARCHAR(80) NOT NULL UNIQUE,
    phone        VARCHAR(15) NOT NULL
);
